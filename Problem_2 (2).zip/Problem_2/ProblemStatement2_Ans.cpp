// HEADERS 
#include<iostream>
#include<cmath>
#include<iomanip>
#include<string>
#include<vector>
#include<algorithm>
#include<map>
#include<set>
#include<utility>
#include<queue>
#include<stack>
#include <random>
#include <fstream>

using namespace std;

// Add tags to distinguish constructors
struct VP_tag {};
struct ER_tag {};

// Linear Rate class for simple interest calculations
class Linear_Rate {
public:
    double VP;  // Present Value
    double ER;  // Effective Rate (%)
    double N;   // Notional Value
    double M;   // Maturity in years

    // Constructor with all parameters
    Linear_Rate(double VP, double ER, double N, double M)
        : VP(VP), ER(ER), N(N), M(M) {
        if (N <= 0 || M <= 0) {
            throw std::invalid_argument("Notional (N) and Maturity (M) must be positive.");
        }
    }

    // Constructor with ER known (calculate VP)
    Linear_Rate(ER_tag, double ER, double N, double M)
        : ER(ER), N(N), M(M), VP(0) {
        if (N <= 0 || M <= 0) {
            throw std::invalid_argument("Notional (N) and Maturity (M) must be positive.");
        }
    }

    // Constructor with VP known (calculate ER)
    Linear_Rate(VP_tag, double VP, double N, double M)
        : VP(VP), N(N), M(M), ER(0) {
        if (N <= 0 || M <= 0) {
            throw std::invalid_argument("Notional (N) and Maturity (M) must be positive.");
        }
    }

    // Calculate price given effective rate (simple linear formula)
    double determine_price_given_ER() {
        // VP = N * (1 - ER * M / 100)
        VP = N * (1 - ER * M / 100.0);
        return VP;
    }

    // Calculate effective rate given present value (simple linear formula)
    double determine_rate_given_VP() {
        if (M == 0) {
            throw std::runtime_error("Maturity (M) cannot be zero.");
        }
        if (N == 0) {
            throw std::runtime_error("Notional (N) cannot be zero.");
        }
        ER = (1 - VP / N) * 100.0 / M;
        return ER;
    }

    // Derivative of VP with respect to ER
    double differentiate_with_respect_to_ER() {
        if (M == 0) {
            throw std::runtime_error("Maturity (M) cannot be zero.");
        }
        return -N * M / 100.0;
    }

    // Derivative of ER with respect to VP
    double differentiate_with_respect_to_VP() {
        if (M == 0) {
            throw std::runtime_error("Maturity (M) cannot be zero.");
        }
        if (N == 0) {
            throw std::runtime_error("Notional (N) cannot be zero.");
        }
        return -1 / (N * M / 100.0);
    }

    // Second derivative (always zero for linear)
    double double_differentiate_with_respect_to_ER_orVP() {
        if (M == 0) {
            throw std::runtime_error("Maturity (M) cannot be zero.");
        }
        return 0;
    }
};

// Cummulative Rate class for coupon bonds
class cummulative_rate {
public:
    double VP;  // Present value of the product
    double N;   // Notional / principal
    double M;   // Maturity (in years)
    double VR;  // Value Rate (coupon rate, annual %)
    double ER;  // Effective Rate (YTM, annual %)
    double PF;  // Payment Frequency (e.g., 2 for semi-annual)

    // Constructor with all parameters
    cummulative_rate(double N, double M, double VR, double ER, double PF)
        : N(N), M(M), VR(VR), ER(ER), PF(PF), VP(0) {
        if (N <= 0 || M <= 0 || PF <= 0) {
            throw std::invalid_argument("Notional (N), Maturity (M), and Payment Frequency (PF) must be positive.");
        }
    }

    // Constructor without ER (default 0)
    cummulative_rate(double N, double M, double VR, double PF)
        : N(N), M(M), VR(VR), PF(PF), ER(0), VP(0) {
        if (N <= 0 || M <= 0 || PF <= 0) {
            throw std::invalid_argument("Notional (N), Maturity (M), and Payment Frequency (PF) must be positive.");
        }
    }

    // Method to compute Present Value given ER
    double determine_price_given_ER() {
        VP = 0; // reset before calculation

        int totalPayments = static_cast<int>(M * PF);
        double ratePerPeriod = ER / (100.0 * PF);
        double couponPayment = (VR * N) / (100.0 * PF);

        // Sum the discounted coupon payments
        for (int i = 1; i <= totalPayments; ++i) {
            VP += couponPayment / pow(1 + ratePerPeriod, i);
        }

        // Add discounted notional at maturity
        VP += N / pow(1 + ratePerPeriod, totalPayments);

        return VP;
    }

    // Method to compute Effective Rate given VP using bisection
    double determine_rate_given_VP() {
        if (VP <= 0 || N <= 0 || M <= 0 || PF <= 0) {
            throw std::runtime_error("Invalid parameters for rate calculation.");
        }

        double low = 0.0, high = 1.0, mid;
        const double tolerance = 1e-6;

        while (high - low > tolerance) {
            mid = (low + high) / 2.0;
            double calculatedVP = 0;

            int totalPayments = static_cast<int>(M * PF);
            double ratePerPeriod = mid / (100.0 * PF);
            double couponPayment = (VR * N) / (100.0 * PF);

            for (int i = 1; i <= totalPayments; ++i) {
                calculatedVP += couponPayment / pow(1 + ratePerPeriod, i);
            }
            calculatedVP += N / pow(1 + ratePerPeriod, totalPayments);

            if (calculatedVP < VP) {
                low = mid; // Increase the rate
            } else {
                high = mid; // Decrease the rate
            }
        }

        ER = mid;
        return ER;
    }

    // Derivative of VP with respect to ER (approximate)
    double differentiate_with_respect_to_ER() {
        if (M == 0 || PF == 0) {
            throw std::runtime_error("Maturity (M) and Payment Frequency (PF) cannot be zero.");
        }
        double dVP_dER = 0;
        int n = static_cast<int>(M * PF);
        double ratePerPeriod = ER / (100.0 * PF);
        double couponPayment = (VR * N) / (100.0 * PF);

        // Calculate the derivative of VP with respect to ER
        for (int i = 1; i <= n; ++i) {
            dVP_dER += -(couponPayment * i / PF) / 100 / pow(1 + ratePerPeriod, PF * (i + 1) / PF);
        }
        dVP_dER += -(N * n / PF) / 100 / pow(1 + ratePerPeriod, n + 1);
        return dVP_dER;
    }

    // Derivative of ER with respect to VP
    double differentiate_with_respect_to_VP() {
        if (M == 0 || PF == 0) {
            throw std::runtime_error("Maturity (M) and Payment Frequency (PF) cannot be zero.");
        }
        ER = determine_rate_given_VP();
        double dER = differentiate_with_respect_to_ER();
        if (dER == 0) {
            throw std::runtime_error("Derivative with respect to ER is zero, cannot compute derivative with respect to VP.");
        }
        return 1 / dER;
    }

    // Second derivative of VP with respect to ER (approximate)
    double double_differentiate_with_respect_to_ER() {
        if (M == 0 || PF == 0) {
            throw std::runtime_error("Maturity (M) and Payment Frequency (PF) cannot be zero.");
        }
        double d2VP_dER2 = 0;
        int n = static_cast<int>(M * PF);
        double ratePerPeriod = ER / (100.0 * PF);
        double couponPayment = (VR * N) / (100.0 * PF);

        for (int i = 1; i <= n; ++i) {
            d2VP_dER2 += (couponPayment * i * (i + 1) / pow(100 * PF, 2)) / pow(1 + ratePerPeriod, (i + 2));
            d2VP_dER2 += (N * n * (n + 1) / pow(100 * PF, 2)) / pow(1 + ratePerPeriod, n + 2);
        }
        return d2VP_dER2;
    }

    // Second derivative of ER with respect to VP
    double double_differentiate_with_respect_to_VP() {
        if (M == 0 || PF == 0) {
            throw std::runtime_error("Maturity (M) and Payment Frequency (PF) cannot be zero.");
        }
        double dVP_dER = differentiate_with_respect_to_ER();
        if (dVP_dER == 0) {
            throw std::runtime_error("First derivative is zero, cannot compute second derivative.");
        }
        return -double_differentiate_with_respect_to_ER() * pow(differentiate_with_respect_to_VP(), 3);
    }
};

// Recursive Rate class for more complex compounding
class recursive_rate {
public:
    double VP;  // Present Value
    double N;   // Notional Value
    double M;   // Maturity in years
    double VR;  // Value Rate (coupon rate, annual %)
    double ER;  // Effective Rate (YTM, annual %)
    double PF;  // Payment Frequency (e.g., 2 for semi-annual)

    // Constructor with all parameters
    recursive_rate(double VP, double N, double M, double VR, double ER, double PF)
        : VP(VP), N(N), M(M), VR(VR), ER(ER), PF(PF) {
        if (N <= 0 || M <= 0 || PF <= 0) {
            throw std::invalid_argument("Notional (N), Maturity (M), and Payment Frequency (PF) must be positive.");
        }
    }

    // Constructor with ER known (calculate VP)
    recursive_rate(ER_tag, double ER, double N, double M, double VR, double PF)
        : ER(ER), N(N), M(M), VR(VR), PF(PF), VP(0) {
        if (N <= 0 || M <= 0 || PF <= 0) {
            throw std::invalid_argument("Notional (N), Maturity (M), and Payment Frequency (PF) must be positive.");
        }
    }

    // Constructor with VP known (calculate ER)
    recursive_rate(VP_tag, double VP, double N, double M, double VR, double PF)
        : VP(VP), N(N), M(M), VR(VR), PF(PF), ER(0) {
        if (N <= 0 || M <= 0 || PF <= 0) {
            throw std::invalid_argument("Notional (N), Maturity (M), and Payment Frequency (PF) must be positive.");
        }
    }

    // Recursive calculation of future value
    double FV(int i) {
        if (i < 0) {
            throw std::invalid_argument("Number of periods (i) cannot be negative.");
        }
        if (i == 0) return 0;
        else {
            return (FV(i - 1) + (VR * N / 100 / PF)) * (1 + ER / 100 / PF);
        }
    }

    // Calculate present value given ER
    double determine_price_given_ER() {
        if (M <= 0 || PF <= 0) {
            throw std::runtime_error("Maturity (M) and Payment Frequency (PF) must be positive.");
        }
        VP = (N + FV(static_cast<int>(M * PF))) / (1 + ER * M / 100);
        return VP;
    }

    // Calculate ER given VP using bisection
    double determine_rate_given_VP() {
        if (M == 0 || PF == 0) {
            throw std::runtime_error("Maturity (M) and Payment Frequency (PF) cannot be zero.");
        }

        double low = 0.0, high = 1.0, mid;
        const double tolerance = 1e-6;

        while (high - low > tolerance) {
            mid = (low + high) / 2.0;
            double calculatedVP = (N + FV(static_cast<int>(M * PF))) / (1 + mid * M / 100);

            if (calculatedVP < VP) {
                low = mid; // Increase the rate
            } else {
                high = mid; // Decrease the rate
            }
        }

        ER = mid;
        return ER;
    }

    // Compute FV and its derivative with respect to ER
    std::pair<double, double> compute_FV_and_derivative() {
        double C = VR * N / (100.0 * PF);
        double r = ER / (100.0 * PF);
        int n = static_cast<int>(M * PF);

        double FV = 0.0;
        double dFV_dER = 0.0;

        for (int i = 1; i <= n; ++i) {
            double temp = FV;
            FV = (FV + C) * (1 + r);
            dFV_dER = dFV_dER * (1 + r) + (temp + C) / (100.0 * PF);
        }

        return {FV, dFV_dER};
    }

    // First derivative of price with respect to ER
    double first_derivative_price_wrt_rate_recursive() {
        auto result = compute_FV_and_derivative();
        double FVn = result.first;
        double dFV_dER = result.second;
        double R = ER * M / 100.0;
        double dR_dER = M / 100.0;
        double numerator = (1 + R) * dFV_dER - (N + FVn) * dR_dER;
        double denominator = (1 + R) * (1 + R);
        return numerator / denominator;
    }

    // First derivative of ER with respect to price
    double first_derivative_rate_wrt_price_recursive() {
        double dVP_dER = first_derivative_price_wrt_rate_recursive();
        if (std::abs(dVP_dER) < 1e-12) {
            throw std::runtime_error("Price derivative too small for rate sensitivity calculation");
        }
        return 1.0 / dVP_dER;
    }

    // Second derivative of price with respect to ER
    double second_derivative_price_wrt_rate_recursive() {
        double C = VR * N / (100.0 * PF);
        double r = ER / (100.0 * PF);
        double dr_dER = 1.0 / (100.0 * PF);
        int n = static_cast<int>(M * PF);

        double FV = 0.0;
        double dFV_dER = 0.0;
        double d2FV_dER2 = 0.0;

        for (int i = 1; i <= n; ++i) {
            double prevFV = FV;
            double prev_dFV_dER = dFV_dER;

            FV = (FV + C) * (1 + r);
            dFV_dER = prev_dFV_dER * (1 + r) + (prevFV + C) * dr_dER;
            d2FV_dER2 = d2FV_dER2 * (1 + r) + 2 * prev_dFV_dER * dr_dER;
        }

        double R = ER * M / 100.0;
        double dR_dER = M / 100.0;
        double d2R_dER2 = 0.0;

        double numerator = (1 + R) * d2FV_dER2
                         - 2 * dR_dER * dFV_dER
                         - (N + FV) * d2R_dER2;

        double denominator = (1 + R) * (1 + R);
        double dVP_dER = ((1 + R) * dFV_dER - (N + FV) * dR_dER) / denominator;

        double d2VP_dER2 = (numerator * (1 + R) - 2 * ((1 + R) * dFV_dER - (N + FV) * dR_dER) * dR_dER) 
                           / pow(1 + R, 3);

        return d2VP_dER2;
    }

    // Second derivative of ER with respect to price
    double second_derivative_rate_wrt_price_recursive() {
        double dVP_dER = first_derivative_price_wrt_rate_recursive();
        double d2VP_dER2 = second_derivative_price_wrt_rate_recursive();

        if (std::abs(dVP_dER) < 1e-12) {
            throw std::runtime_error("Price derivative too small for rate sensitivity calculation");
        }

        return -d2VP_dER2 * pow(dVP_dER, 3);
    }
};

enum class RelativeFactorType {
    Unity,
    Cumulative
};

// A ValueNote wrapper for the basket
struct ValueNote {
    cummulative_rate note;
    ValueNote(const cummulative_rate& note) : note(note) {}
};

// DeliveryContract class with basket and RelativeFactor calculation
class DeliveryContract {
public:
    int number_of_contracts;
    std::vector<ValueNote> basket;
    RelativeFactorType rf_type;
    double standardized_value_rate; // Used for CumulativeFactor

    DeliveryContract(int n_contracts, const std::vector<ValueNote>& basket,
                     RelativeFactorType rf_type, double svr)
        : number_of_contracts(n_contracts), basket(basket),
          rf_type(rf_type), standardized_value_rate(svr) {}

    // Calculate RelativeFactor for a ValueNote
    double get_relative_factor(const ValueNote& vn) const {
        if (rf_type == RelativeFactorType::Unity) {
            return 1.0;
        } else if (rf_type == RelativeFactorType::Cumulative) {
            // Price when ER = SVR, divided by 100
            cummulative_rate temp = vn.note;
            temp.ER = standardized_value_rate;
            double price = temp.determine_price_given_ER();
            return price / 100.0;
        }
        return 1.0;
    }

    // Display RelativeFactors for all ValueNotes in the basket
    void display_relative_factors() const {
        cout << "\nRelative Factors for each ValueNote in the basket:\n";
        for (size_t i = 0; i < basket.size(); ++i) {
            cout << "ValueNote " << i << ": RF = " << get_relative_factor(basket[i]) << endl;
        }
    }
};

// Solve a quadratic equation a*x^2 + b*x + c = 0
double solve_quadratic(double a, double b, double c) {
    double discriminant = b * b - 4 * a * c;
    if (discriminant < 0) throw std::runtime_error("No real roots for the quadratic equation.");
    double sqrt_disc = std::sqrt(discriminant);
    double x1 = (-b + sqrt_disc) / (2 * a);
    double x2 = (-b - sqrt_disc) / (2 * a);
    // Return the positive root (since ER should be positive)
    if (x1 > 0 && x2 > 0) return std::min(x1, x2);
    if (x1 > 0) return x1;
    if (x2 > 0) return x2;
    throw std::runtime_error("No positive root for the quadratic equation.");
}

// Simulate ER at expiration for a ValueNote
double simulate_ER_expiry(double ER0, double sigma, double T_years) {
    static std::mt19937 rng(std::random_device{}());
    std::normal_distribution<> norm(0.0, 1.0);
    double z = norm(rng);
    return ER0 * exp(sigma * sqrt(T_years) * z - 0.5 * sigma * sigma * T_years);
}

// Calculate forward price at expiry using the convention from the image
double forward_price_at_expiry(
    double VP0,
    const std::vector<double>& cashflows, // coupon/principal payments
    const std::vector<double>& times,     // times (years) of each cashflow
    double r_t,                           // risk-free rate
    double expiry_time                    // T in years
) {
    double sum = 0.0;
    for (size_t j = 0; j < cashflows.size(); ++j) {
        if (times[j] > expiry_time) continue;
        sum += cashflows[j] / pow(1 + r_t, times[j]);
    }
    return (1 + r_t * expiry_time) * (VP0 - sum);
}

// Calculate Relative Factor
double calc_relative_factor(const cummulative_rate& note, RelativeFactorType rf_type, double svr) {
    if (rf_type == RelativeFactorType::Unity) return 1.0;
    cummulative_rate temp = note;
    temp.ER = svr;
    return temp.determine_price_given_ER() / 100.0;
}

// Integrated DeliveryContract menu with all requirements
void delivery_contract_menu() {
    cout << "\n--- Delivery Contract  ---\n";
    int n;
    cout << "Enter number of contracts: "; cin >> n;
    int basket_size;
    cout << "Enter number of ValueNotes in basket: "; cin >> basket_size;
    vector<cummulative_rate> notes;
    vector<double> sigmas;
    vector<vector<double>> cashflows(basket_size);
    vector<vector<double>> times(basket_size);

    for (int i = 0; i < basket_size; ++i) {
        double N, M, VR, ER, PF, sigma;
        cout << "ValueNote " << i << ":\n";
        cout << "  Notional: "; cin >> N;
        cout << "  Maturity (years): "; cin >> M;
        cout << "  Value Rate (%): "; cin >> VR;
        cout << "  Effective Rate (YTM, %): "; cin >> ER;
        cout << "  Payment Frequency: "; cin >> PF;
        cout << "  Volatility (sigma): "; cin >> sigma;
        notes.emplace_back(N, M, VR, ER, PF);
        sigmas.push_back(sigma);

        // Build cashflows and times for this ValueNote
        int totalPayments = static_cast<int>(M * PF);
        double couponPayment = (VR * N) / (100.0 * PF);
        for (int j = 1; j <= totalPayments; ++j) {
            cashflows[i].push_back(couponPayment);
            times[i].push_back(j / PF);
        }
        // Add principal at maturity
        cashflows[i].push_back(N);
        times[i].push_back(M);
    }

    cout << "Choose Relative Factor type:\n";
    cout << "1. UnityFactor\n";
    cout << "2. CumulativeFactor\n";
    int rf_choice; cin >> rf_choice;
    RelativeFactorType rf_type = (rf_choice == 2) ? RelativeFactorType::Cumulative : RelativeFactorType::Unity;
    double svr = 0.0;
    if (rf_type == RelativeFactorType::Cumulative) {
        cout << "Enter Standardized Value Rate (SVR): "; cin >> svr;
    }
    int months;
    cout << "Enter expiration time (months): "; cin >> months;
    double T_years = months / 12.0;
    double risk_free_rate;
    cout << "Enter risk-free rate (%): "; cin >> risk_free_rate;
    risk_free_rate /= 100.0; // convert to decimal

    // For each ValueNote, simulate ER at expiry, calculate forward price, and solve quadratic
    for (int i = 0; i < basket_size; ++i) {
        double ER_T = simulate_ER_expiry(notes[i].ER, sigmas[i], T_years);

        // Calculate VP0 using current ER
        double VP0 = notes[i].determine_price_given_ER();

        // Calculate forward price at expiry using the convention
        double fwd_price = forward_price_at_expiry(VP0, cashflows[i], times[i], risk_free_rate, T_years);

        // Analytical derivatives at expiry (using simulated ER_T)
        cummulative_rate note_expiry = notes[i];
        note_expiry.ER = ER_T;
        double dVP_dER = note_expiry.differentiate_with_respect_to_ER();
        double d2VP_dER2 = note_expiry.double_differentiate_with_respect_to_ER();

        // Quadratic coefficients (from your formula)
        double a = 0.5 * d2VP_dER2 * std::exp(sigmas[i] * sigmas[i] * T_years);
        double b = dVP_dER;
        double c = -dVP_dER * ER_T;

        double ER_risk_adj = 0.0;
        try {
            ER_risk_adj = solve_quadratic(a, b, c);
        } catch (const std::exception& ex) {
            cout << "ValueNote " << i << ": Error solving quadratic: " << ex.what() << endl;
            continue;
        }

        double RF = calc_relative_factor(notes[i], rf_type, svr);

        cout << "ValueNote " << i << ":\n";
        cout << "  Simulated ER_T = " << ER_T << endl;
        cout << "  Forward Price at Expiry = " << fwd_price << endl;
        cout << "  Risk-adjusted ER at Expiry (quadratic root) = " << ER_risk_adj << endl;
        cout << "  Relative Factor = " << RF << endl;
    }
}



// Helper to write the submission CSV
void write_submission_csv(
    const std::vector<std::vector<std::string>>& results,
    const std::vector<double>& RFs,
    const std::string& filename = "output.csv"
) {
    std::ofstream file(filename);
    file << ",Linear,Cumulative,Recursive,Q 2.1,Q 2.2,Q 2.3,Q 2.4 a),Q 2.4 b)\n";
    std::vector<std::string> row_names = {
        "Q 1.1 a)", "Q 1.1 b)", "Q 1.2 a)", "Q 1.2 b)", "Q 1.3 a)", "Q 1.3 b)"
    };
    for (size_t i = 0; i < results.size(); ++i) {
        file << row_names[i];
        
        
        for (const auto& val : results[i]) file << "," << val;
         // Add RF for this row
        file << "\n";
    }
    // Write Q2.1 RFs column-wise, one per row, other columns blank
    // for (size_t i = 0; i < RFs.size(); ++i) {
    //     file << "Q 2.1";
    //     file << ",,,," << RFs[i] << ",,,," << "\n";
    // }
    file.close();
    std::cout << "Results written to " << filename << "\n";
}

// Submission mode
void submission_mode() {
    std::cout << "\n--- Submission Mode ---\n";
    std::vector<cummulative_rate> notes;
    std::vector<Linear_Rate> linear_notes;
    std::vector<recursive_rate> recursive_notes;
    int n = 4;
    std::cout << "Enter 4 ValueNotes (N, M, VR, PF):\n";
    for (int i = 0; i < n; ++i) {
        double N, M, VR, PF;
        std::cout << "ValueNote " << i << ":\n";
        std::cout << "  Notional: "; std::cin >> N;
        std::cout << "  Maturity (years): "; std::cin >> M;
        std::cout << "  Value Rate (%): "; std::cin >> VR;
        std::cout << "  Payment Frequency: "; std::cin >> PF;
        // For Linear, ER is not needed for construction, but for price calculation we will ask later
        linear_notes.emplace_back(ER_tag{}, 0.0, N, M);
        notes.emplace_back(N, M, VR, 0.0, PF);
        recursive_notes.emplace_back(ER_tag{}, 0.0, N, M, VR, PF);
    }
    std::cout << "Choose Relative Factor type:\n";
    std::cout << "1. UnityFactor\n";
    std::cout << "2. CumulativeFactor\n";
    int rf_choice; std::cin >> rf_choice;
    RelativeFactorType rf_type = (rf_choice == 2) ? RelativeFactorType::Cumulative : RelativeFactorType::Unity;
    double svr = 0.0;
    if (rf_type == RelativeFactorType::Cumulative) {
        std::cout << "Enter Standardized Value Rate (SVR): "; std::cin >> svr;
    }

    // Q1.1a: Ask ER, calculate price for ValueNote 0 for each convention
    double ER_input;
    std::cout << "Q1.1a) Enter Effective Rate (%): "; std::cin >> ER_input;
    // Linear
    linear_notes[0].ER = ER_input;
    double linear_price = linear_notes[0].determine_price_given_ER();
    // Cumulative
    notes[0].ER = ER_input;
    double cumulative_price = notes[0].determine_price_given_ER();
    // Recursive
    recursive_notes[0].ER = ER_input;
    double recursive_price = recursive_notes[0].determine_price_given_ER();

    // Q1.1b: Ask VP, calculate ER for ValueNote 0 for each convention
    double VP_input;
    std::cout << "Q1.1b) Enter Present Value: "; std::cin >> VP_input;
    // Linear
    linear_notes[0].VP = VP_input;
    double linear_rate = linear_notes[0].determine_rate_given_VP();
    // Cumulative
    notes[0].VP = VP_input;
    double cumulative_rate = notes[0].determine_rate_given_VP();
    // Recursive
    recursive_notes[0].VP = VP_input;
    double recursive_rate = recursive_notes[0].determine_rate_given_VP();

    // Q1.2a: Price sensitivity to ER for ValueNote 0 at ER_input
    
    std::cout << "Q1.2a) Enter Effective Rate (%): "; std::cin >> ER_input;
    linear_notes[0].ER = ER_input;
    notes[0].ER = ER_input;
    recursive_notes[0].ER = ER_input;
    double linear_dVPdER = linear_notes[0].differentiate_with_respect_to_ER();
    double cumulative_dVPdER = notes[0].differentiate_with_respect_to_ER();
    double recursive_dVPdER = recursive_notes[0].first_derivative_price_wrt_rate_recursive();

    // Q1.2b: ER sensitivity to price for ValueNote 0 at VP_input
    
    std::cout << "Q1.2b) Enter Present Value: "; std::cin >> VP_input;
    linear_notes[0].VP = VP_input;
    notes[0].VP = VP_input;
    recursive_notes[0].VP = VP_input;
    double linear_dERdVP = linear_notes[0].differentiate_with_respect_to_VP();
    double cumulative_dERdVP = notes[0].differentiate_with_respect_to_VP();
    double recursive_dERdVP = recursive_notes[0].first_derivative_rate_wrt_price_recursive();

    // Q1.3a: Second derivative of price w.r.t ER for ValueNote 0 at 
    
    std::cout << "Q1.3a) Enter Effective Rate (%): "; std::cin >> ER_input;
    linear_notes[0].ER = ER_input;
    notes[0].ER = ER_input;
    recursive_notes[0].ER = ER_input;
    double linear_d2VPdER2 = linear_notes[0].double_differentiate_with_respect_to_ER_orVP();
    double cumulative_d2VPdER2 = notes[0].double_differentiate_with_respect_to_ER();
    double recursive_d2VPdER2 = recursive_notes[0].second_derivative_price_wrt_rate_recursive();

    // Q1.3b: Second derivative of ER w.r.t price for ValueNote 0 at VP_input
    std::cout << "Q1.3b) Enter Present Value: "; std::cin >> VP_input;
    linear_notes[0].VP = VP_input;
    notes[0].VP = VP_input;
    recursive_notes[0].VP = VP_input;
    double linear_d2ERdVP2 = linear_notes[0].double_differentiate_with_respect_to_ER_orVP();
    double cumulative_d2ERdVP2 = notes[0].double_differentiate_with_respect_to_VP();
    double recursive_d2ERdVP2 = recursive_notes[0].second_derivative_rate_wrt_price_recursive();

    // Q2.1: RF for each ValueNote
    std::vector<double> RFs(4);
    for (int i = 0; i < 4; ++i) {
        RFs[i] = calc_relative_factor(notes[i], rf_type, svr);
    }

    // Prepare results for CSV
    std::vector<std::vector<std::string>> results(6, std::vector<std::string>(3, "1"));
    // Q1.1a
    results[0][0] = std::to_string(linear_price);
    results[0][1] = std::to_string(cumulative_price);
    results[0][2] = std::to_string(recursive_price);
    results[0][3] = std::to_string(RFs[0]); // Q2.1 will be filled separately
    results[0][4] = "0"; //q2.2 will be filled separately
    results[0][5] = "0"; //q2.3 will be filled separately
    results[0][6] = "0"; //q2.4 a) will be filled separately
    results[0][7] = "0"; //q2.4 b) will be filled separately
    // Q1.1b
    results[1][0] = std::to_string(linear_rate);
    results[1][1] = std::to_string(cumulative_rate);
    results[1][2] = std::to_string(recursive_rate);
    results[1][3] = std::to_string(RFs[1]); // Q2.1 will be filled separately
    results[1][4] = "0";
    results[1][5] = "0";
    results[1][6] = "0";
    results[1][7] = "0";

    // Q1.2a
    results[2][0] = std::to_string(linear_dVPdER);
    results[2][1] = std::to_string(cumulative_dVPdER);
    results[2][2] = std::to_string(recursive_dVPdER);
    results[2][3] = std::to_string(RFs[2]); // Q2.1 will be filled separately
    results[2][4] = "0";
    results[2][5] = "0";
    results[2][6] = "0";
    results[2][7] = "0";

    // Q1.2b
    results[3][0] = std::to_string(linear_dERdVP);
    results[3][1] = std::to_string(cumulative_dERdVP);
    results[3][2] = std::to_string(recursive_dERdVP);
    results[3][3] = std::to_string(RFs[3]); // Q2.1 will be filled separately
    results[3][4] = "0";
    results[3][5] = "0";
    results[3][6] = "0";
    results[3][7] = "0";

    // Q1.3a
    results[4][0] = std::to_string(linear_d2VPdER2);
    results[4][1] = std::to_string(cumulative_d2VPdER2);
    results[4][2] = std::to_string(recursive_d2VPdER2);
    results[4][3] = "";
    results[4][4] = "0";
    results[4][5] = "0";
    results[4][6] = "0";
    results[4][7] = "0";

    // Q1.3b
    results[5][0] = std::to_string(linear_d2ERdVP2);
    results[5][1] = std::to_string(cumulative_d2ERdVP2);
    results[5][2] = std::to_string(recursive_d2ERdVP2);
    results[5][3] = "";
    results[5][4] = "0";
    results[5][5] = "0";
    results[5][6] = "0";
    results[5][7] = "0";


    // Write to CSV
    write_submission_csv(results, RFs);

    // Write Q2.1 RFs to console for confirmation
    std::cout << "Q2.1 Relative Factors (RFs): ";
    for (int i = 0; i < 4; ++i) std::cout << RFs[i] << " ";
    std::cout << "\n";
}

// Default submission mode with predefined parameters
void default_submission_mode() {
    // Default ValueNotes from the table
    std::vector<double> N = {100, 100, 100, 100};
    std::vector<double> M = {5, 1.5, 4.5, 10};
    std::vector<double> VR = {3.5, 2, 3.25, 8};
    std::vector<double> PF = {1, 2, 1, 4};

    std::vector<cummulative_rate> notes;
    std::vector<Linear_Rate> linear_notes;
    std::vector<recursive_rate> recursive_notes;
    int n = 4;
    for (int i = 0; i < n; ++i) {
        linear_notes.emplace_back(ER_tag{}, 0.0, N[i], M[i]);
        notes.emplace_back(N[i], M[i], VR[i], 0.0, PF[i]);
        recursive_notes.emplace_back(ER_tag{}, 0.0, N[i], M[i], VR[i], PF[i]);
    }
    // Q2.1: RF for each ValueNote
    
    
    RelativeFactorType rf_type = RelativeFactorType::Cumulative;
    double svr = 5.0;
    std::vector<double> RFs(4);
    for (int i = 0; i < 4; ++i) {
        RFs[i] = calc_relative_factor(notes[i], rf_type, svr);
    }
    // Use UnityFactor for RFs by default, SVR not needed
    // RelativeFactorType rf_type = RelativeFactorType::Unity;
    // double svr = 0.0;

    // Use ER = 5% and PV = 100 as default for all calculations
    double ER_input = 5.0;
    double VP_input = 100.0;

    // Q1.1a: Price for ValueNote 0 for each convention at ER=5%
    linear_notes[0].ER = ER_input;
    double linear_price = linear_notes[0].determine_price_given_ER();
    notes[0].ER = ER_input;
    double cumulative_price = notes[0].determine_price_given_ER();
    recursive_notes[0].ER = ER_input;
    double recursive_price = recursive_notes[0].determine_price_given_ER();

    // Q1.1b: Rate for ValueNote 0 for each convention at PV=100
    linear_notes[0].VP = VP_input;
    double linear_rate = linear_notes[0].determine_rate_given_VP();
    notes[0].VP = VP_input;
    double cumulative_rate = notes[0].determine_rate_given_VP();
    recursive_notes[0].VP = VP_input;
    double recursive_rate = recursive_notes[0].determine_rate_given_VP();

    // Q1.2a: Price sensitivity to ER for ValueNote 0 at ER=5%
    linear_notes[0].ER = ER_input;
    notes[0].ER = ER_input;
    recursive_notes[0].ER = ER_input;
    double linear_dVPdER = linear_notes[0].differentiate_with_respect_to_ER();
    double cumulative_dVPdER = notes[0].differentiate_with_respect_to_ER();
    double recursive_dVPdER = recursive_notes[0].first_derivative_price_wrt_rate_recursive();

    // Q1.2b: ER sensitivity to price for ValueNote 0 at PV=100
    linear_notes[0].VP = VP_input;
    notes[0].VP = VP_input;
    recursive_notes[0].VP = VP_input;
    double linear_dERdVP = linear_notes[0].differentiate_with_respect_to_VP();
    double cumulative_dERdVP = notes[0].differentiate_with_respect_to_VP();
    double recursive_dERdVP = recursive_notes[0].first_derivative_rate_wrt_price_recursive();

    // Q1.3a: Second derivative of price w.r.t ER for ValueNote 0 at ER=5%
    linear_notes[0].ER = ER_input;
    notes[0].ER = ER_input;
    recursive_notes[0].ER = ER_input;
    double linear_d2VPdER2 = linear_notes[0].double_differentiate_with_respect_to_ER_orVP();
    double cumulative_d2VPdER2 = notes[0].double_differentiate_with_respect_to_ER();
    double recursive_d2VPdER2 = recursive_notes[0].second_derivative_price_wrt_rate_recursive();

    // Q1.3b: Second derivative of ER w.r.t price for ValueNote 0 at PV=100
    linear_notes[0].VP = VP_input;
    notes[0].VP = VP_input;
    recursive_notes[0].VP = VP_input;
    double linear_d2ERdVP2 = linear_notes[0].double_differentiate_with_respect_to_ER_orVP();
    double cumulative_d2ERdVP2 = notes[0].double_differentiate_with_respect_to_VP();
    double recursive_d2ERdVP2 = recursive_notes[0].second_derivative_rate_wrt_price_recursive();

    

    // Prepare results for CSV
    std::vector<std::vector<std::string>> results(6, std::vector<std::string>(8,"0"));
    // Q1.1a
    results[0][0] = std::to_string(linear_price);
    results[0][1] = std::to_string(cumulative_price);
    results[0][2] = std::to_string(recursive_price);
    results[0][3] = std::to_string(RFs[0]); // Q2.1 will be filled separately
    // Q1.1b
    results[1][0] = std::to_string(linear_rate);
    results[1][1] = std::to_string(cumulative_rate);
    results[1][2] = std::to_string(recursive_rate);
    results[1][3] = std::to_string(RFs[1]); // Q2.1 will be filled separately
    // Q1.2a
    results[2][0] = std::to_string(linear_dVPdER);
    results[2][1] = std::to_string(cumulative_dVPdER);
    results[2][2] = std::to_string(recursive_dVPdER);
    results[2][3] = std::to_string(RFs[2]); // Q2.1 will be filled separately
    // Q1.2b
    results[3][0] = std::to_string(linear_dERdVP);
    results[3][1] = std::to_string(cumulative_dERdVP);
    results[3][2] = std::to_string(recursive_dERdVP);
    results[3][3] = std::to_string(RFs[3]); // Q2.1 will be filled separately
    // Q1.3a
    results[4][0] = std::to_string(linear_d2VPdER2);
    results[4][1] = std::to_string(cumulative_d2VPdER2);
    results[4][2] = std::to_string(recursive_d2VPdER2);
    results[4][3] = ""; // Q2.1 will be filled separately
    
    // Q1.3b
    results[5][0] = std::to_string(linear_d2ERdVP2);
    results[5][1] = std::to_string(cumulative_d2ERdVP2);
    results[5][2] = std::to_string(recursive_d2ERdVP2);
    results[5][3] = ""; // Q2.1 will be filled separately

    // Write to CSV
    write_submission_csv(results, RFs);

    // Write Q2.1 RFs to console for confirmation
    std::cout << "Q2.1 Relative Factors (RFs): ";
    for (int i = 0; i < 4; ++i) std::cout << RFs[i] << " ";
    std::cout << "\n";
}

// Add normal mode menus for Linear, Cumulative, Recursive
void linear_rate_menu() {
    cout << "\n--- Linear Rate Model ---\n";
    cout << "1. Calculate Price given ER\n";
    cout << "2. Calculate ER given Price\n";
    cout << "3. Derivative of Price w.r.t ER\n";
    cout << "4. Derivative of ER w.r.t Price\n";
    cout << "5. Second Derivative (both directions)\n";
    cout << "0. Back\n";
    int op; cin >> op;
    if (op == 0) return;
    try {
        double N, M, ER, VP;
        switch (op) {
            case 1:
                cout << "Enter Effective Rate (%): "; cin >> ER;
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "Price (VP): " << Linear_Rate(ER_tag{}, ER, N, M).determine_price_given_ER() << endl;
                break;
            case 2:
                cout << "Enter Present Value: "; cin >> VP;
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "Effective Rate (ER): " << Linear_Rate(VP_tag{}, VP, N, M).determine_rate_given_VP() << endl;
                break;
            case 3:
                cout << "Enter Effective Rate (%): "; cin >> ER;
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "dVP/dER: " << Linear_Rate(ER_tag{}, ER, N, M).differentiate_with_respect_to_ER() << endl;
                break;
            case 4:
                cout << "Enter Present Value: "; cin >> VP;
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "dER/dVP: " << Linear_Rate(VP_tag{}, VP, N, M).differentiate_with_respect_to_VP() << endl;
                break;
            case 5:
                cout << "Enter Effective Rate (%): "; cin >> ER;
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "Second Derivative: " << Linear_Rate(ER_tag{}, ER, N, M).double_differentiate_with_respect_to_ER_orVP() << endl;
                break;
            default: cout << "Invalid operation.\n";
        }
    } catch (const std::exception& ex) {
        cerr << "Error: " << ex.what() << endl;
    }
}

void cummulative_rate_menu() {
    cout << "\n--- Cumulative Rate Model ---\n";
    cout << "1. Calculate Price given ER\n";
    cout << "2. Calculate ER given Price\n";
    cout << "3. Derivative of Price w.r.t ER\n";
    cout << "4. Derivative of ER w.r.t Price\n";
    cout << "5. Second Derivative (both directions)\n";
    cout << "0. Back\n";
    int op; cin >> op;
    if (op == 0) return;
    try {
        double N, M, VR, ER, PF, VP;
        switch (op) {
            case 1:
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "Enter Value Rate (%): "; cin >> VR;
                cout << "Enter Effective Rate (YTM, %): "; cin >> ER;
                cout << "Enter Payment Frequency: "; cin >> PF;
                cout << "Price (VP): " << cummulative_rate(N, M, VR, ER, PF).determine_price_given_ER() << endl;
                break;
            case 2:
                cout << "Enter Present Value: "; cin >> VP;
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "Enter Value Rate (%): "; cin >> VR;
                cout << "Enter Payment Frequency: "; cin >> PF;
                cout << "Effective Rate (ER): " << cummulative_rate(N, M, VR, PF).determine_rate_given_VP() << endl;
                break;
            case 3:
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "Enter Value Rate (%): "; cin >> VR;
                cout << "Enter Effective Rate (YTM, %): "; cin >> ER;
                cout << "Enter Payment Frequency: "; cin >> PF;
                cout << "dVP/dER: " << cummulative_rate(N, M, VR, ER, PF).differentiate_with_respect_to_ER() << endl;
                break;
            case 4:
                cout << "Enter Present Value: "; cin >> VP;
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "Enter Value Rate (%): "; cin >> VR;
                cout << "Enter Payment Frequency: "; cin >> PF;
                cout << "dER/dVP: " << cummulative_rate(N, M, VR, PF).differentiate_with_respect_to_VP() << endl;
                break;
            case 5:
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "Enter Value Rate (%): "; cin >> VR;
                cout << "Enter Effective Rate (YTM, %): "; cin >> ER;
                cout << "Enter Payment Frequency: "; cin >> PF;
                cout << "Second Derivative d2VP/dER2: " << cummulative_rate(N, M, VR, ER, PF).double_differentiate_with_respect_to_ER() << endl;
                cout << "Second Derivative d2ER/dVP2: " << cummulative_rate(N, M, VR, PF).double_differentiate_with_respect_to_VP() << endl;
                break;
            default: cout << "Invalid operation.\n";
        }
    } catch (const std::exception& ex) {
        cerr << "Error: " << ex.what() << endl;
    }
}

void recursive_rate_menu() {
    cout << "\n--- Recursive Rate Model ---\n";
    cout << "1. Calculate Price given ER\n";
    cout << "2. Calculate ER given Price\n";
    cout << "3. Derivative of Price w.r.t ER\n";
    cout << "4. Derivative of ER w.r.t Price\n";
    cout << "5. Second Derivative (both directions)\n";
    cout << "0. Back\n";
    int op; cin >> op;
    if (op == 0) return;
    try {
        double N, M, VR, ER, PF, VP;
        switch (op) {
            case 1:
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "Enter Value Rate (%): "; cin >> VR;
                cout << "Enter Effective Rate (YTM, %): "; cin >> ER;
                cout << "Enter Payment Frequency: "; cin >> PF;
                cout << "Price (VP): " << recursive_rate(ER_tag{}, ER, N, M, VR, PF).determine_price_given_ER() << endl;
                break;
            case 2:
                cout << "Enter Present Value: "; cin >> VP;
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "Enter Value Rate (%): "; cin >> VR;
                cout << "Enter Payment Frequency: "; cin >> PF;
                cout << "Effective Rate (ER): " << recursive_rate(VP_tag{}, VP, N, M, VR, PF).determine_rate_given_VP() << endl;
                break;
            case 3:
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "Enter Value Rate (%): "; cin >> VR;
                cout << "Enter Effective Rate (YTM, %): "; cin >> ER;
                cout << "Enter Payment Frequency: "; cin >> PF;
                cout << "dVP/dER: " << recursive_rate(ER_tag{}, ER, N, M, VR, PF).first_derivative_price_wrt_rate_recursive() << endl;
                break;
            case 4:
                cout << "Enter Present Value: "; cin >> VP;
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "Enter Value Rate (%): "; cin >> VR;
                cout << "Enter Payment Frequency: "; cin >> PF;
                cout << "dER/dVP: " << recursive_rate(VP_tag{}, VP, N, M, VR, PF).first_derivative_rate_wrt_price_recursive() << endl;
                break;
            case 5:
                cout << "Enter Notional Value: "; cin >> N;
                cout << "Enter Maturity (years): "; cin >> M;
                cout << "Enter Value Rate (%): "; cin >> VR;
                cout << "Enter Effective Rate (YTM, %): "; cin >> ER;
                cout << "Enter Payment Frequency: "; cin >> PF;
                cout << "Second Derivative d2VP/dER2: " << recursive_rate(ER_tag{}, ER, N, M, VR, PF).second_derivative_price_wrt_rate_recursive() << endl;
                cout << "Second Derivative d2ER/dVP2: " << recursive_rate(ER_tag{}, ER, N, M, VR, PF).second_derivative_rate_wrt_price_recursive() << endl;
                break;
            default: cout << "Invalid operation.\n";
        }
    } catch (const std::exception& ex) {
        cerr << "Error: " << ex.what() << endl;
    }
}

// Update main menu
int main() {
    default_submission_mode(); // Run default submission mode first
    while (true) {
        cout << "\n==== Interest Rate Model Calculator ====\n";
        cout << "Select Mode:\n";
        cout << "1. Normal Mode\n";
        cout << "2. Submission Mode (for CSV)\n";
        cout << "3. Default Submission (auto, no input)\n";
        cout << "0. Exit\n";
        cout << "Choice: ";
        int mode; cin >> mode;
        if (mode == 0) break;
        if (mode == 1) {
            cout << "\nSelect Model:\n";
            cout << "1. Linear Rate\n";
            cout << "2. Cumulative Rate\n";
            cout << "3. Recursive Rate\n";
            cout << "4. Delivery Contract\n";
            cout << "0. Back\n";
            int model; cin >> model;
            if (model == 0) continue;
            switch (model) {
                case 1: linear_rate_menu(); break;
                case 2: cummulative_rate_menu(); break;
                case 3: recursive_rate_menu(); break;
                case 4: delivery_contract_menu(); break;
                default: cout << "Invalid model type.\n";
            }
        } else if (mode == 2) {
            submission_mode();
        } else if (mode == 3) {
            default_submission_mode();
        } else {
            cout << "Invalid mode.\n";
        }
    }
    cout << "Exiting...\n";
    return 0;
}
